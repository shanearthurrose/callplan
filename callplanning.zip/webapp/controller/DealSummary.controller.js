sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast"
	], function(Controller, JSONModel, History) {
	"use strict";
	
	
	var hasOwnProperty = Object.prototype.hasOwnProperty;

	function assign() {
	    var target = {};
	
	    for (var i = 0; i < arguments.length; i++) {
	        var source = arguments[i];
	
	        for (var key in source) {
	            if (hasOwnProperty.call(source, key)) {
	                target[key] = source[key];
	            }
	        }
	    }
	
	    return target;
	}
	
	return Controller.extend("callplanning.controller.DealSummary", {
		onInit: function() {
			var oTableControl = this.getView().byId("summaryTable");
			var oCalculator = this.getView().byId("summary-calc-container");
			var oDetails = this.getView().byId("summaryItemTable");
			var sDefaultBindingPath = "dealSummary>/xsdLocal1:Account/xsdLocal1:ListOfLnAccountDealsSummary/xsdLocal1:LnAccountDealsSummary/0";
			var sPathSegment = sDefaultBindingPath + '/xsdLocal1:ListOfLnAccountDeals-Week0/xsdLocal1:LnAccountDeals-Week0';
			
			this.oTableControl = oTableControl;
			this.oCalculatorControl = oCalculator;
			this.oItemTableControl = oDetails;
			
			// the key 2 x 6 Pack offer was changed from 2 x 6 Pack Offer 12/24
			this.unitToDenominator = {
				'2 x 6 Pack Offer': 0.5,
				'2 x Carton Offer': 2,
				'3 for Offer (3/12)': 0.25,
				'6 Pack': 1,
				'6 Pack (6/24)': 0.25,
				'10 Pack': 0.25,
				'1 x Mini Keg (1/2)': 0.5,
				'Advertised': 1,
				'Advertised - Lead': 1,
				'Bonus Buy': 1,
				'Catalogue': 1,
				'EDP': 1,
				'In Store': 1,
				'In Store - Lead': 1,
				'Incentive': 1,
				'KSP': 1,
				'LWS': 1,
				'MWS': 1,
				'OAD': 1
			};
			
			
			// AUD -> A$ and USD -> $ when using sap standard formatting with Currency type
		   // either build a custom type to do this or just add the $ to
			
			var summaryCalcData = {
				currency: '$',
				SummaryItem: [
					{
						LNProdGroupDescription: '',
						LNExecutionType: '',
						LNExecutionNotesWeek0: '',
						ExecutionNotesBuyDay: '',
						LNStartDate: '',
						LNEndDate: '',
						LNListPrice: '',
						LNBuyMOQ: '',
						LNFullPalletBenefit: '',
						LNPSDDollarsWeek0: '',
						LNTPRDollars: '',
						LNOtherTPRCalcWeek0: '',
						LNTotalDiscCalcWeek0Detail: '',
						LNLUCWeek0Detail: '',
						LNRRP: '',
						LNGPDollarsWeek0: '',
						LNWETWeek0: '',
						LNCDL: ''
					}
				],
				Unit: [
					{
						Item: '10-Pack Promotion'
					},
					{
						Item: '2 x Carton Offer'
					},
					{
						Item: '2 X 6 Pack Offer'
					},
					{
						Item: '1 X Mini Keg (1/2)'
					},
					{
						Item: '3 for Offer (3/12)'
					},
					{
						Item: '6 Pack (6/24)'	
					},
					{
						Item: 'Default use'
					},
					{
						Item: '3 packs/12 case'
					},
					{
						Item: 'Single/12 case'
					},
					{
						Item: 'Single /18 case'
					},
					{
						Item: 'Single/24Case'
					},
					{
						Item:'Single/30Case'
					},
					{
						Item:'2x5L Kegs'
					},
					{
						Item: '4 Packs/24 case'
					},
					{
						Item: '570ml'
					},
					{
						Item: '500ml'
					},
					{
						Item:'425ml'
					},
					{
						Item:'285ml'
					},
					{
						Item:'255ml'
					}
				]
			};
			
			var unitModel = new JSONModel(summaryCalcData);
			this.getView().setModel(unitModel,"unitModel");
			oDetails.bindItems({
				path: sPathSegment,
				template: oDetails.getBindingInfo("items").template
			});
			
			this.getRouter().getRoute("dealsummary").attachPatternMatched(this.onEnter, this);
		},
		 getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);  
		},
		
		onEnter: function(oEvent) {
			debugger
			var $shell = $('.sapMShellCentralBox');
			if($shell.length > 0) {
				$shell.addClass('dealsummary-width');
			}
			var oCustomer = this.getOwnerComponent()._getCustomer();
			var oTableControl = this.oTableControl;
			var oCalculatorControl = this.oCalculatorControl;
			var oItemTableControl = this.oItemTableControl;
			oTableControl.setBusy(true);
			var accountId;
			if(oCustomer != null) {
				accountId = oCustomer.getAccountId();
			}
			
			var controls = {
				table: oTableControl,
				calc: oCalculatorControl,           
				item: oItemTableControl
			};
			var week=0;
			this.getOwnerComponent().getDealSummary(accountId, week,controls);
		},
		
		onNavBack : function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} 
		},
		
		onBack: function() {
			var oWeekButton = this.getView().byId("weekselectbutton");
			if(oWeekButton != null) {
				oWeekButton.setSelectedKey("thisWeek");
			}
			var $shell = $('.sapMShellCentralBox');
			if($shell.length > 0) {
				$shell.removeClass('dealsummary-width');
			}
			jQuery.sap.delayedCall(100, this, function() {
				this.getOwnerComponent()._onProcessFlowPress(this.getOwnerComponent().prevView);
			});
			sap.ui.core.BusyIndicator.show(10);
		},
		
		onSummaryItemSelected: function(oEvent) {
			var oItem = oEvent.getSource();
			var modelName = "dealSummary";
			var sPathSegment = oEvent.getSource().getBindingContext("dealSummary").getPath() + '/xsdLocal1:ListOfLnAccountDeals-Week0/xsdLocal1:LnAccountDeals-Week0';
			var sPath= modelName + ">" + sPathSegment;
			var oModel = this.getOwnerComponent().getModel("dealSummary");
			var summaryCalcModel = this.getOwnerComponent().getModel("dealSummaryCalc");
			var oCalculator = this.getView().byId("summary-calc-container");
			var oDetails = this.getView().byId("summaryItemTable");
			var oCalcDefaults = {
				listPrice: 0,
				fpb: 0,
				dluc: 0,
				unit: 0,
				psd: 0,
				otherDiscount: 0,
				freight: 0,
				rrp: 0,
				tpr: 0,
				wet: 0,
				netLuc: 0,
				gp: 0,
				gpPc: 0,
				otherTpr: 0,
				cdl: 0,
				oc: 0,
				totalDiscount: 0,
				bc: 0
			};
			
			var sCalcPathSegment = sPathSegment + "/xsdLocal1:ListOfLnAccountDealsProfitCalcWeek0Vbc/0/xsdLocal1:LnAccountDealsProfitCalcWeek0Vbc";
			
			var listPrice = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:ListPrice");
			var fpb = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:FullPalletBenefit");
			var dluc = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:DiscountLUCWeek0");
			var unit = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:LNUnit");
			var psd = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:PSDWeek0");
			var otherDiscount = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:Other");
			var rrp = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:RRP");
			var tpr = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:TPR");
			var wet = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:WETWeek0");
			var netLuc = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:LUCWeek0");
			var freight = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:Freight");
			var gp = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:GrossProfitAmtWeek0");
			var gpPc = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:GrossProfitPercentWeek0");
			var otherTpr = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:OtherTPRAmountWeek0");
			var cdl = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:CDL");
			//var oc = oModel.getProperty(sPathSegment + "/Calculated");
			var totalDiscount = oModel.getProperty(sCalcPathSegment + "/0/xsdLocal1:TotalDiscountAmtWeek0");
			//var bc = oModel.getProperty(sPathSegment + "/Calculated");
			
			var oCalcModelData = {
				listPrice: listPrice,
				fpb: fpb,
				dluc: dluc,
				unit: unit,
				psd: psd,
				otherDiscount: otherDiscount,
				freight: freight,
				rrp: rrp,
				tpr: tpr,
				wet: wet,
				netLuc: netLuc,
				gp: gp,
				gpPc: gpPc,
				otherTpr: otherTpr,
				cdl: cdl,
				totalDiscount: totalDiscount
			};
			
			var oCalcData = assign(oCalcDefaults, oCalcModelData);
			summaryCalcModel.setData(oCalcData);
			
			oCalculator.bindElement(sPath);
			oDetails.bindItems({
				path: sPath,
				template: oDetails.getBindingInfo("items").template
			});
			/*
				manually append the path and set the binding for `calculator`
				set up the binding for SummaryItem
			*/	
		},
		
		onCalcFieldChange: function(oEvent) {
			this.calcFields = [
				{
					id: 'list_price_summarycalc_input',
					label: 'List Price ex GST'
				},
				{
					id: 'psd_summarycalc_input',
					label: 'PSD $'
				},
				{
					id: 'tpr_summarycalc_input',
					label: 'TPR $'
				},
				{
					id:'othertpr_summarycalc_input',
					label: 'Other TPR $'
				},
				{
					id: 'total_discount_summarycalc_input',
					label: 'Total Discount'
				},
				{
					id: 'fullpallet_summarycalc_input',
					label: 'Full Pallet Benefit'
				},
				{
					id: 'other_summarycalc_input',
					label: 'Other'
				},
				{
					id: 'wet_summarycalc_input',
					label: 'WET'
				},
				{
					id: 'cdl_summarycalc_input',
					label: 'CDL'
				},
				{
					id: 'bonuscartons_summarycalc_input',
					label: 'Bonus Cartons'
				},
				{
					id: 'discountLuc_summarycalc_input',
					label: 'Discount LUC'
				},
				{
					id: 'freight_summarycalc_input',
					label: 'Freight'
				},
			 {
				   id: 'netLuc_summarycalc_input',
			    label: 'Net LUC ex GST'
			 },
			 {
					id: 'orderedcartons_summarycalc_input',
					label: 'Ordered Cartons'
				},
			 {
				   id: 'unit_summarycalc_select',
				   label: 'Unit'
			 },
			 {
					label: 'RRP Per Unit',
					id: 'rrp_summarycalc_input'
				},
			 {
					label: 'Gross Profit $',
					id: 'gross_profit_summarycalc_input'
				},
			 {
					label: 'Gross Profit %',
			     id: 'gross_profitpc_summary_calc_input'
			  }
	
			];
			
			
			 var oParams = oEvent.getParameters();
			 var oControl = oEvent.getSource();
			 var sId = oEvent.getSource().getId();
			 
			 var numberValue = /[-]?\d+([.]\d{0,2})?/;
			 var sLabel = this.calcFields.filter(function(item){
			 	return sId.indexOf(item.id) > 0;
			 })[0].label;
			 var sValue;
			 if(sLabel === "Unit") {
			 	sValue = oParams.selectedItem.getText();
				sValue = this.unitToDenominator[sValue];
			 } else {
				sValue = oParams.value;	
			 }
			 
			 /*get only number value from the property without any additional formatting on the values*/
			 
			 if(typeof sValue === "string") {
				sValue = numberValue.exec(sValue)[0];	
			 }
			 
			 var iValue;
			 if(sValue!= "" && sValue != null) {
			 	iValue = Number(sValue);
			 	if(!isNaN(iValue)) {
					var oModel = this.getOwnerComponent().getModel("dealSummaryCalc");
					var oData = this.getOwnerComponent().getModel("dealSummaryCalc").getData();
					if(sLabel === "Unit") {
						oData.denominator = iValue;
					}
					var psd = oData.psd;
					var tpr = oData.tpr;
					var otherTpr = oData.otherTpr;
					var totalDiscount = this.calcTotalDiscount(psd, tpr, otherTpr);
					var discountLuc = this.calcDiscountLUC(oData);
					var netLuc = this.calcNetLUC(oData);
					var gp$ = this.calcGrossProfit(oData);
					var gpPc = this.calcGrossProfitPC(oData);
					
					oModel.setProperty("/totalDiscount",totalDiscount);
					oModel.setProperty("/dluc", discountLuc);
					oModel.setProperty("/netLuc", netLuc);
					oModel.setProperty("/gp",gp$); 
					oModel.setProperty("/gpPc", gpPc); 		
			 	} else {
			 		sap.m.MessageToast.show(sLabel + " must be a number ");
			 	}
			 } else {
			 	if(sLabel !== "Unit") {
			 		sap.m.MessageToast.show(sLabel + " cannot be empty");		
			 	}
			 }
		},
		
	calcTotalDiscount: function(psd, tpr, otherTpr) {
		psd = Number(psd);
		tpr = Number(tpr);
		otherTpr = Number(otherTpr);
		if(!isNaN(psd) && !isNaN(tpr) && !isNaN(otherTpr)) {
			return psd + tpr + otherTpr;	
		}
	},
	
	calcDiscountLUC: function(oData) {
		var keys = ['listPrice', 'psd', 'tpr', 'otherTpr', 'fpb', 'otherDiscount', 'wet', 'cdl'];
		var allNaNs = keys.filter(function(item){
			return isNaN(Number(oData[item]));
		});
		
		var compute = !(allNaNs.length > 0);
		
		var listPrice = Number(oData.listPrice);
		var psd = Number(oData.psd);
		var tpr = Number(oData.tpr);
		var otherTpr = Number(oData.otherTpr);
		var fpb = Number(oData.fpb);
		var otherDiscount = Number(oData.otherDiscount);
		var wet = Number(oData.wet);
		var cdl = Number(oData.cdl);
	
		if(compute) {
			var totalDiscount =  Number(this.calcTotalDiscount(psd,tpr,otherTpr));
			if(!isNaN(totalDiscount)) {
				var discountLuc = listPrice - totalDiscount - fpb - otherDiscount + wet + cdl;
			}
			return discountLuc;
		}
	},
	
	calcNetLUC: function(oData) {
		var keys = ['freight'];
		var allNaNs = keys.filter(function(item){
			return isNaN(Number(oData[item]));
		});
		
		var compute = !(allNaNs.length > 0);
		var freight = Number(oData.freight);
		var oc = Number(oData.oc);
		var bc = Number(oData.bc);
		var netLuc;
		if(compute) {
			var dluc = Number(this.calcDiscountLUC(oData));
			if(!isNaN(dluc)) {
				netLuc = dluc + freight;
				if(!isNaN(oc) && !isNaN(bc) && oc !== 0 && bc !== 0) {
					netLuc = (netLuc * oc)/(oc + bc);
				}
				return netLuc;
			}
		}
	},
	
	calcGrossProfit: function (oData) {
		var denominator = oData.denominator;
		var rrp = Number(oData.rrp);
		var gp;
		var nluc = this.calcNetLUC(oData);
		if(nluc != null && rrp != null && !isNaN(rrp)) {
			if(denominator !=null && !isNaN(denominator)) {
				gp = (rrp/1.1) - (nluc * denominator);
			} else {
				gp = (rrp/1.1) - nluc;
			}
			return gp;
		}
	},
	
	// calcWet: function (oData) {
	// 	var listPrice = Number(oData.listPrice);
	// 	var fpb = Number(oData.fpb);
	// 	var wetRate = Number(oData.wetRate);
	// 	var psd = Number(oData.psd);
	// 	var tpr = Number(oData.tpr);
	// 	var otherTpr = Number(oData.otherTpr);
	// 	var otherDiscount = Number(oData.otherDiscount);
	// 	var cdl = Number(oData.cdl);
	// 	var totalDiscount = this.calcTotalDiscount(psd, tpr, otherTpr);
	// 	var canCompute = !isNaN(listPrice) && !isNaN(fpb) && !isNaN(wetRate) && !isNaN(otherDiscount) && !isNaN(cdl) && !isNaN(totalDiscount);
	// 	if(canCompute) {
	// 		var wet = (listPrice - totalDiscount - fpb - otherDiscount + cdl)* wetRate;
	// 		if(!isNaN(wet)) {
	// 			return wet;
	// 		}
	// 	}
	// },
	
	onItemsTableRowSelected: function (oEvent) {

		var oModel = this.getOwnerComponent().getModel("dealSummary");
		var sPathSegment = oEvent.getSource().getBindingContext("dealSummary").getPath() + "/xsdLocal1:ListOfLnAccountDealsProfitCalcWeek0Vbc/0/xsdLocal1:LnAccountDealsProfitCalcWeek0Vbc";
		var summaryCalcModel = this.getOwnerComponent().getModel("dealSummaryCalc");
		var oCalcDefaults = {
				listPrice: 0,
				fpb: 0,
				dluc: 0,
				unit: 0,
				psd: 0,
				otherDiscount: 0,
				freight: 0,
				rrp: 0,
				tpr: 0,
				wet: 0,
				netLuc: 0,
				gp: 0,
				gpPc: 0,
				otherTpr: 0,
				cdl: 0,
				oc: 0,
				totalDiscount: 0,
				bc: 0
			};
			
			var listPrice = oModel.getProperty(sPathSegment + "/xsdLocal1:ListPrice");
			var fpb = oModel.getProperty(sPathSegment + "/xsdLocal1:FullPalletBenefit");
			var dluc = oModel.getProperty(sPathSegment + "/xsdLocal1:DiscountLUCWeek0");
			var unit = oModel.getProperty(sPathSegment + "xsdLocal1:LNUnit");
			var psd = oModel.getProperty(sPathSegment + "/xsdLocal1:PSDWeek0");
			var otherDiscount = oModel.getProperty(sPathSegment + "/xsdLocal1:Other");
			var rrp = oModel.getProperty(sPathSegment + "/xsdLocal1:RRP");
			var tpr = oModel.getProperty(sPathSegment + "/xsdLocal1:TPR");
			var wet = oModel.getProperty(sPathSegment + "/xsdLocal1:WETWeek0");
			var netLuc = oModel.getProperty(sPathSegment + "/xsdLocal1:LUCWeek0");
			var freight = oModel.getProperty(sPathSegment + "/xsdLocal1:Freight");
			var gp = oModel.getProperty(sPathSegment + "/xsdLocal1:GrossProfitAmtWeek0");
			var gpPc = oModel.getProperty(sPathSegment + "/xsdLocal1:GrossProfitPercentWeek0");
			var otherTpr = oModel.getProperty(sPathSegment + "/xsdLocal1:OtherTPRAmountWeek0");
			var cdl = oModel.getProperty(sPathSegment + "/xsdLocal1:CDL");
			//var oc = oModel.getProperty(sPathSegment + "/Calculated");
			var totalDiscount = oModel.getProperty(sPathSegment + "/xsdLocal1:TotalDiscountAmtWeek0");
			//var bc = oModel.getProperty(sPathSegment + "/Calculated");
			
			var oCalcModelData = {
				listPrice: listPrice,
				fpb: fpb,
				dluc: dluc,
				unit: unit,
				psd: psd,
				otherDiscount: otherDiscount,
				freight: freight,
				rrp: rrp,
				tpr: tpr,
				wet: wet,
				netLuc: netLuc,
				gp: gp,
				gpPc: gpPc,
				otherTpr: otherTpr,
				cdl: cdl,
				totalDiscount: totalDiscount
			};
			
			var oCalcData = assign(oCalcDefaults, oCalcModelData);
			summaryCalcModel.setData(oCalcData);
	},
	
	onWeekSelected: function(oEvent) {
		var sText = oEvent.getParameters().key;
		var week;
		if(sText === 'thisWeek') {
			week = 0;
		} else if(sText === 'nextWeek') {
			week = 1;
		} else if(sText === '+2Weeks') {
			week = 2;
		}
		
		var oCustomer = this.getOwnerComponent()._getCustomer();
		var oTableControl = this.oTableControl;
		var oCalculatorControl = this.oCalculatorControl;
		var oItemTableControl = this.oItemTableControl;
		var accountId;
		
		if(oCustomer != null) {
			accountId = oCustomer.getAccountId();
		}
		
		if(week != null) {
			var controls = {
				table: oTableControl,
				calc: oCalculatorControl,           
				item: oItemTableControl
			};
			this.getOwnerComponent().getDealSummary(accountId, week, controls);			
		}
	},
	calcGrossProfitPC: function (oData) {
		var gp$ = this.calcGrossProfit(oData);
		var rrp = Number(oData.rrp);
		var gpPc;
		if(gp$ != null && rrp != null && !isNaN(gp$) && !isNaN(rrp) && rrp !== 0) {
			gpPc = 100 * (gp$/(rrp/1.1));
			gpPc = gpPc.toFixed(2);
			return gpPc;
		}
	},
	dollarFormatter: function (value) {
		if (value !== "" && value != null) {
			value = Number(value);
			if(!isNaN(value)) {
				value = value.toFixed(2);
				return '$ ' + value;
			}
			return value;
		}
		return value;
	},
	percentFormatter: function (value) {
		if (value !== "" && value !== null) {
			value = Number(value);
			if(value === 0) {
				return value;
			}
			if(!isNaN(value)) {
				value = value.toFixed(2);
				return value + '%';
			}
		}
	}
	});
});