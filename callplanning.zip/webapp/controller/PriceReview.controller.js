sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("callplanning.controller.PriceReview", {

		onInit: function() {
			// TODO

			var prevView = this.getOwnerComponent().prevView;
			var priceReviewConfig = new sap.ui.model.json.JSONModel({
				prevView: prevView
			});
			

			this.getOwnerComponent()._getLOV("REVIEW_TYPE_VALUE_FIELD", "Reason Code - Price Review", "PriceReviewReasonCode");
			this.getOwnerComponent()._getLOV("REVIEW_TYPE_VALUE_FIELD", "Price Corr On Ent- PriceReview", "PriceReviewPriceCorrectOnEntry");			

			this.getView().setModel(priceReviewConfig, "priceReviewConfig");
			var oRouter = this.getOwnerComponent().getRouter();
			/*
			Attach a listener to the view, so fm: _selectItemWithId will be called everytime this view is triggered via Route
			*/

			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "pricereview") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));

			}, this);
			
			var currencyModel = new sap.ui.model.json.JSONModel({
				currency: '$'	
			});
			
			this.getView().setModel(currencyModel, "priceReviewCurrency");

		},
		
		onTableInitialized: function (oEvent) {
			var prevView = this.getOwnerComponent().prevView;
			var oTable = this.getView().byId("tblPriceReview");
			var oRows = oTable.getItems();
			var oRow;
			var oCells;
			var oPriceCorrect;
			var sPriceCorrect;
			var oActualPrice;
			var sActualPrice;
			var oPriceAmended;
			var sPriceAmended;
			var oReasonCode;
			var sReasonCode;
			
			this.canProceed = {};
			
			
			if(oRows != null && oRows.length > 0) {
				for(var i = 0;i < oRows.length; i++) {
					oRow = oRows[i];
					oCells = oRow.getCells();
					if(oCells.length > 0 && Array.isArray(oCells)) {
						oPriceCorrect = oCells[7];
						oActualPrice = oCells[8];
						oPriceAmended = oCells[9];
						oReasonCode = oCells[10];
						sPriceCorrect = oPriceCorrect.getValue();
						sActualPrice = oActualPrice.getValue().slice(1).trim();
						sPriceAmended = oPriceAmended.getValue();
						sReasonCode = oReasonCode.getValue();
						/*
							SAP UI5 might or might not use the same table and change the data instead of destroying the table
							and creating a new one ( which might be a more expensive thing, thus we detach any listeners to ensure
							that we are not responsible for binding multiple event listeners to a control and for keeping controls in memory
							as zombie views when they should be destroyed)
						*/
						
						if(isNaN(Number(sActualPrice)) || Number(sActualPrice) === 0) {
							debugger
							sActualPrice = "";
							oActualPrice.setValue(sActualPrice);
						}
						
						if(sPriceCorrect === "Yes" || sPriceCorrect === "Not Ranged") {
							oActualPrice.setEditable(false);	
							oActualPrice.setRequired(false);
							oActualPrice.setValue("");
							
						} else if(prevView === "plan") {
							oActualPrice.setEditable(true);	
							oActualPrice.setRequired(true);
						}
						
						
						if (prevView === "plan" && sPriceCorrect.indexOf("-") > 0) {
							if(sActualPrice == null || sActualPrice === "") {
								oActualPrice.attachChange(this.onLockingControlChange, this);
							} else {
								oActualPrice.detachChange(this.onLockingControlChange, this);
							}
						}
						
						if (prevView === "sell") {
							if (sPriceCorrect === "No - Above") {
								oPriceAmended.setEditable(true);
								oReasonCode.setEditable(true);
								oPriceAmended.setRequired(true);
								oReasonCode.setRequired(true);
								if(sActualPrice == null || sActualPrice === "") {
									oActualPrice.attachChange(this.onLockingControlChange, this);
								} else {
									oActualPrice.detachChange(this.onLockingControlChange, this);
								}
								if(sPriceAmended == null || sPriceAmended === "") {
									oPriceAmended.attachSelectionChange(this.onLockingControlChange, this);
								} else {
									oPriceAmended.detachSelectionChange(this.onLockingControlChange, this);
								}
								
								if(sReasonCode == null  || sReasonCode === "") {
									oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
								} else {
									oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
								}
							} else if (sPriceCorrect === "Not Ranged") {
								oActualPrice.setEditable(false);
								oActualPrice.setValueState("None");
								oActualPrice.setValue("");
								oActualPrice.setRequired(false);
								oReasonCode.setEditable(true);
								oReasonCode.setRequired(true);
								oPriceAmended.setEditable(false);
								oPriceAmended.setRequired(false);
								if(sReasonCode == null  || sReasonCode === "") {
									oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
								} else {
									oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
								}
							}
						}
					}
				}
			}
		},
		
		onLockingControlChange: function(oEvent) {
			var oParams = oEvent.getParameters();
			var oControl = oEvent.getSource();
			
			
			var sBindingPath = oEvent.getSource().getBindingContext("PriceReview").getPath();
			var oModel = this.getOwnerComponent().getModel("PriceReview");
			var oParams = oEvent.getParameters();
			
			var sId = oControl.getId();
			var $row = $('#' + sId).closest("tr");
			var sRowId;
			if($row.length > 0) {
				sRowId = $row.prop("id");
			}    
			
			var oCells = oControl.getParent();
			var prevView = this.getOwnerComponent().prevView;
			
			if (oCells.getCells && !Array.isArray(oCells)) {
				oCells = oCells.getCells();	
			}

			var sPriceDiscrepencyType = oModel.getProperty(sBindingPath + "/review:valueFieldA");
			var sValueNum;
			var sRRP;
			var oInput;
			var oPriceAmended = oCells[9];
			var oReasonCode = oCells[10];
			var sPriceAmended;
			var sReasonCode;
			var showPopup = false;
			var sValue;
			// ensure that we have a Number here
			oInput = oCells[8];
			
			if(sPriceDiscrepencyType.indexOf("-") > 0 && prevView === "plan") {
				// test for crazy values here:
				debugger
				var bInvalid  = this.validateBadInput(oParams.value,sRowId,oInput);
				if(bInvalid) {
					return;
				}
			}
			
			
			sValue = oInput.getValue().slice(1);
			if (sValue != null && sValue !== "" && !isNaN(Number(sValue))) {
				sValueNum = Number(sValue);
			} else if(isNaN(Number(sValue)) || Number(sValue) === 0) {
				sValue = "";
				sValueNum = null;
			}
			sRRP = Number(oModel.getProperty(sBindingPath + "/review:numberFieldA"));
				if (!isNaN(sRRP)) {
					switch (sPriceDiscrepencyType) {
						case 'No - Above': {
							if (prevView === "plan") {
								if (Number(sRRP) >= sValueNum) { 
									oInput.setValueState("Error");
									this.canProceed = {
										row: sRowId,
										message: 'Actual Price cannot be lower than the RRP when Price Correct in Store is No - Above',
										fields: [
											oInput.getId()
										]
									};
									this.lockUnansweredRows(sRowId);
									showPopup = false;
								} else {
									oInput.detachChange(this.lockingControlChange, this);
									this.unlockAllRows();
									showPopup = false;
								}
							}
									
							else if (prevView === "sell") {
								sPriceAmended = oPriceAmended.getValue();
								sReasonCode = oReasonCode.getValue();
								
								var allEmpty = ( sValue ==="" || sValue == null ) &&
									( sPriceAmended === "" || sPriceAmended == null ) &&
									( sReasonCode === "" || sReasonCode == null );
								
								var emptyInput = sValue ==="" || sValue == null;
								var isValueLower = sValueNum <= Number(sRRP);
								var isValueCorrect = sValueNum > Number(sRRP);
								var nonEmptyPriceAmended = sPriceAmended != null && sPriceAmended !== "";
								var nonEmptyReasonCode = sReasonCode != null && sReasonCode !== "";
								
								var neitherSelected = 	( sPriceAmended === "" || sPriceAmended == null ) &&
									( sReasonCode === "" || sReasonCode == null );
								
								var onlyReasonCodeEmpty =  isValueCorrect && nonEmptyPriceAmended && !nonEmptyReasonCode;
								var onlyPriceAmendedEmpty = isValueCorrect && nonEmptyReasonCode && !nonEmptyPriceAmended;
								var inputAndReasonCodeEmpty = emptyInput && !nonEmptyReasonCode && nonEmptyPriceAmended;
								var inputAndPriceAmendedEmpty = emptyInput && !nonEmptyPriceAmended && nonEmptyReasonCode;
								var lowerValueAndEmptyPriceAmended = isValueLower && !nonEmptyPriceAmended && nonEmptyReasonCode;
								var lowerValueAndEmptyReasonCode = isValueLower && !nonEmptyReasonCode && nonEmptyPriceAmended;
								
								var bothSelected = nonEmptyReasonCode && nonEmptyPriceAmended;
								var onlyInputEmpty = emptyInput && bothSelected;
								var onlyInputErroneous = isValueLower && bothSelected;
								
								if(allEmpty) {
									oInput.setValueState("Error");
									oPriceAmended.setValueState("Error");
									oReasonCode.setValueState("Error");
									
									this.canProceed = {
										row: sRowId,
										message: 'Actual Price, Price Amended and Reason Code must not be empty when Price Correct in store is No - Above and a discrepency has been created',
										fields: [
											oInput.getId(),
											oPriceAmended.getId(),
											oReasonCode.getId()
										]
									};
									
									this.lockUnansweredRows(sRowId);
									showPopup = true;
										
								} else if(inputAndPriceAmendedEmpty) {
									oInput.setValueState("Error");
									oPriceAmended.setValueState("Error");
									oReasonCode.setValueState("None");
									
									this.canProceed = {
										row: sRowId,
										message: 'Actual Price and Price Amended cannot be empty when Price Correct in Store is No - Above and a discrepency has been created',
										fields: [
											oInput.getId(),
											oPriceAmended.getId()
										]
									};
									
									this.lockUnansweredRows(sRowId);
									showPopup = true;
									
								} else if(inputAndReasonCodeEmpty) {
									
									oInput.setValueState("Error");
									oPriceAmended.setValueState("None");
									oReasonCode.setValueState("Error");
									
									this.canProceed = {
										row: sRowId,
										message: 'Actual Price and Reason Code cannot be empty when Price Correct in Store is No - Above and a discrepency has been created',
										fields: [
											oInput.getId(),
											oReasonCode.getId()
										]
									};
									
									this.lockUnansweredRows(sRowId);
									showPopup = true;
									
								}
								
								else if(isValueLower && neitherSelected) {
									oInput.setValueState("Error");
									oPriceAmended.setValueState("Error");
									oReasonCode.setValueState("Error");
									
									this.canProceed = {
										row: sRowId,
										message: 'Actual Price must be higher than RRP, Price Amended and Reason Code must not be empty when Price Correct in store is No - Above and a discrepency has been created',
										fields: [
											oInput.getId(),
											oPriceAmended.getId(),
											oReasonCode.getId()
										]
									};
									
									this.lockUnansweredRows(sRowId);
									showPopup = true;
								} else if(lowerValueAndEmptyPriceAmended) {
									
									oInput.setValueState("Error");
									oPriceAmended.setValueState("Error");
									oReasonCode.setValueState("None");
									
									this.canProceed = {
										row: sRowId,
										message: 'Actual Price must be higher than RRP and Price Amended cannot be empty when Price Correct in store is No - Above and a discrepency has been created',
										fields: [
											oInput.getId(),
											oPriceAmended.getId()
										]
									};
									
									this.lockUnansweredRows(sRowId);
									showPopup = true;
								} else if(lowerValueAndEmptyReasonCode) {
									
									oInput.setValueState("Error");
									oPriceAmended.setValueState("None");
									oReasonCode.setValueState("Error");
									
									this.canProceed = {
										row: sRowId,
										message: 'Actual Price must be higher than RRP and Price Amended cannot be empty when Price Correct in store is No - Above and a discrepency has been created',
										fields: [
											oInput.getId(),
											oReasonCode.getId()
										]
									};
									this.lockUnansweredRows(sRowId);									
									showPopup = true;
									
								} else if(isValueCorrect && neitherSelected) {
									oInput.setValueState("None");
									
									oPriceAmended.setValueState("Error");
									oReasonCode.setValueState("Error");
									
									this.canProceed = {
										row: sRowId,
										message: 'Price Amended and Reason Code cannot be empty when Price Correct in store change is No - Above and discrepency has been created',
										fields: [
											oPriceAmended.getId(),
											oReasonCode.getId()
										]
									};
									this.lockUnansweredRows(sRowId);
									oInput.detachChange(this.lockingControlChange, this);
									showPopup = true;
								} else if(onlyReasonCodeEmpty) {
									oInput.setValueState("None");
									oPriceAmended.setValueState("None");
									oReasonCode.setValueState("Error");
									
									this.canProceed = {
										row: sRowId,
										message: 'Reason Code cannot be empty when Price Correct in store change is No - Above and discrepency has been created',
										fields: [
											oReasonCode.getId()
										]
									};
									
									this.lockUnansweredRows(sRowId);
									oInput.detachChange(this.lockingControlChange, this);
									oPriceAmended.detachSelectionChange(this.lockingControlChange, this);
									showPopup = true;
									
								} else if(onlyPriceAmendedEmpty) {
									oInput.setValueState("None");
									oReasonCode.setValueState("None");
									oPriceAmended.setValueState("Error");
									
									this.canProceed = {
										row: sRowId,
										message: 'Price Amended cannot be empty when Price Correct in store change is No - Above and discrepency has been created',
										fields: [
											oPriceAmended.getId()	
										]
									};
									
									this.lockUnansweredRows(sRowId);
									oInput.detachChange(this.lockingControlChange, this);
									oReasonCode.detachSelectionChange(this.lockingControlChange, this);
									showPopup = true;
								} else if(onlyInputEmpty) {
									//COLLAPSE this and the next condition into the next one
									oInput.setValueState("Error");
									oReasonCode.setValueState("None");
									oPriceAmended.setValueState("None");
									
									this.canProceed = {
										row: sRowId,
										fields: [
											oInput.getId()
										],
										message: 'Actual Price cannot be empty when Price Correct in store change is No-Above'
									};
									this.lockUnansweredRows(sRowId);
									showPopup = false;
								} else if(onlyInputErroneous) {
									oInput.setValueState("Error");
									oReasonCode.setValueState("None");
									oPriceAmended.setValueState("None");
									
									this.canProceed = {
										row: sRowId,
										fields: [
											oInput.getId()
										],
										message: 'Actual Price cannot be lower than RRP when Price Correct in store change is No - Above'
									};
									
									this.lockUnansweredRows(sRowId);
									showPopup = false;
									oReasonCode.detachSelectionChange(this.lockingControlChange, this);
									oPriceAmended.detachSelectionChange(this.lockingControlChange, this);
								} else {
									oInput.setValueState("None");
									oReasonCode.setValueState("None");
									oPriceAmended.setValueState("None");
									this.canProceed = null;
									showPopup = false;
									
									this.unlockAllRows();
									oInput.detachChange(this.lockingControlChange, this);
									oReasonCode.detachSelectionChange(this.lockingControlChange, this);
									oPriceAmended.detachSelectionChange(this.lockingControlChange, this);
								
								}
								
								if(showPopup) {
									if(this.canProceed && this.canProceed.message) {
										sap.m.MessageToast.show(this.canProceed.message);
									}
								}
								
							} else {
								oInput.setValueState("None");
								oReasonCode.setValueState("None");
								oPriceAmended.setValueState("None");
								this.canProceed = null;
								showPopup = false;
								
								this.unlockAllRows();
								oInput.detachChange(this.lockingControlChange, this);
								oReasonCode.detachSelectionChange(this.lockingControlChange, this);
								oPriceAmended.detachSelectionChange(this.lockingControlChange, this);
								
							}
							
							break;
						}
						case 'No - Below': {
									debugger
									if (sValue== null || sValue === "" || isNaN(sValueNum)) {
										this.canProceed = {
											row: sRowId,
											message: 'Actual Price cannot be empty when Price Correct in store is No - Below',
											fields: [
												oInput.getId()
											]
										};
										oInput.setValueState("Error");
										this.lockUnansweredRows(sRowId);
										showPopup = false;
									} 
									
									if(Number(sRRP) <= sValueNum) {
										this.canProceed = {
											row: sRowId,
											message: 'Actual Price cannot be higher than RRP when Price Correct in store change is No - Below',
											fields: [
												oInput.getId()
											]
										};
										
										oInput.setValueState("Error");
										this.lockUnansweredRows(sRowId);
										showPopup = false;
									} 
									
									if (Number(sRRP) > sValueNum) {
											oInput.setValueState("None");
											oInput.detachChange(this.lockingControlChange, this);
											this.unlockAllRows();
									}	
								break;
							}
						case 'Not Ranged': {
							oInput.setEditable(false);
							oInput.setValue("");
							oInput.setValueState("None");
							sReasonCode = oReasonCode.getSelectedKey();
							if(sReasonCode !== "" && sReasonCode != null) {
								oReasonCode.setValueState("None");
								oReasonCode.detachSelectionChange(this.lockingControlChange, this);
								this.unlockAllRows();
							}
							break;
						}
						default: {
								// DUPLICATE LOGIC (???)
								oInput.setEditable(false);
								oInput.setValue("");
								oInput.setValueState(sap.ui.core.ValueState.None);
								oInput.detachChange(this.lockingControlChange, this);
								this.unlockAllRows();
							}
					}
				}
			// }
			// if (sPriceDiscrepencyType.indexOf("-") !== -1) {
			// 	var goodValue = sValue !== "" && sValue != null && sValue.length > 0 && !isNaN(Number(sValue));
			// 	if (goodValue) {
			// 			oInput.setValueState(sap.ui.core.ValueState.None);
			// 			oInput.setRequired(false);
			// 			oInput.detachChange(this.onLockingControlChange, this);	
			// 	}
			// }
		
		},
		
		unlockAllRows: function () {
			var oTable = this.getView().byId("tblPriceReview");
			var oItems = oTable.getItems();
			var oRow;
			var sPriceCorrect;
			var oCells;
			var prevView = this.getOwnerComponent().prevView;
			for(var i=0; i< oItems.length; i++) {
				oRow = oItems[i];
				oCells = oRow.getCells();
				if(prevView === "plan") {
					oCells[7].setEditable(true);	
				}
				
				sPriceCorrect = oCells[7].getValue();
				if(prevView === "plan") {
					if(sPriceCorrect === "No - Above" || sPriceCorrect === "No - Below") {
						oCells[8].setEditable(true);	
					}	
				}
				
				
				if(sPriceCorrect === "No - Above" && prevView === "sell") {
					oCells[9].setEditable(true);
					oCells[10].setEditable(true);
				}
				
				if(sPriceCorrect === "Not Ranged" && prevView === "sell") {
					oCells[10].setEditable(true);
				}
				
				oCells[11].setEditable(true);
			}
			if (this.canProceed != null) {
				this.canProceed.locked = false;
			}
		},
		
		lockUnansweredRows: function (sRowId) {
			// this function cannot be generalised
			var oTable = this.getView().byId("tblPriceReview");
			var oItems = oTable.getItems();
			var oRow;
			var sId;
			var oCells;
			for(var i=0; i< oItems.length; i++) {
				oRow = oItems[i];
				sId = oRow.getId();
				if (sId !== sRowId) {
					oCells = oRow.getCells();
					oCells[7].setEditable(false);
					oCells[8].setEditable(false);
					oCells[9].setEditable(false);
					oCells[10].setEditable(false);
					oCells[11].setEditable(false);
				}
			}
			if (this.canProceed != null) {
				this.canProceed.locked = true;
			}
		},
		
		enableActualPrice: function(prevView, priceInStore) {
			prevView = this.getOwnerComponent().prevView;
			if(priceInStore.indexOf("-") > 0 && prevView === "plan") {
				return true;
			}
			return false;
		},
		
		enableReasonCode: function (prevView, priceInStore) {
			prevView = this.getOwnerComponent().prevView;
			if (prevView === 'sell') {
				if(priceInStore.indexOf("Above") > 0) {
					return true;
				} else if(priceInStore.indexOf('Ranged') > 0) {
					return true;
				} 
				// else if(priceInStore.indexOf('Below') > 0) {
				// 	return true;
				// }
 			}
			return false;			
		},
		
		enablePriceAmended: function (prevView, priceInStore) {
			prevView = this.getOwnerComponent().prevView;
			if (prevView === 'sell') {
				if(priceInStore.indexOf("Above") > 0) {
					return true;
				} 
				// else if(priceInStore.indexOf('Below') > 0) {
				// 	return true;
				// }
 			}
 			return false;
		},

		isNoAbove: function(prevView, priceInStore) {
			prevView = this.getOwnerComponent().prevView;
			
			if (prevView === 'sell') {
				if(priceInStore.indexOf("Above") > 0) {
					return true;
				} else if(priceInStore.indexOf('Ranged') > 0) {
					return true;
				} else if(priceInStore.indexOf('Below') > 0) {
					return true;
				}
 			}
			return false;
		},

		_selectItemWithId: function(arg) {
			var oCustomer = this.getOwnerComponent()._getCustomer();
			var oOutlet = this.getOwnerComponent()._getOutlet();
			//alert("this");
			//implementation
			var callId = oCustomer.getActivityId();
			var accountId = oCustomer.getAccountId();
			var clgwwgFlag = "N";
			//			alert(this.getOwnerComponent().prevView);
			// set fields available

			//var accountId = "1-2N362F";
			//var callId = "1-4BERT9C"; 
			if (oOutlet.getAddress().toLowerCase().indexOf("clg/wwg") !== -1) {
				clgwwgFlag = "Y";
			}

			this.getOwnerComponent()._getPriceReviewData(this.byId("tblPriceReview"), accountId, callId, clgwwgFlag);
			sap.ui.core.BusyIndicator.hide();
		},

		onBack: function() {
			//	window.history.go(-1);
			//alert(this.getOwnerComponent().prevView);
			this.canProceed = {};
			// fixes error remains when user exits with error
			var oTable = this.getView().byId("tblPriceReview");
			var oRows = oTable.getItems();
			if (oRows != null && oRows.length > 0) {
				for (var i = 0; i < oRows.length; i++) {
					var oRow = oRows[i];
					var oCells = oRow.getCells();
					oCells[7].setValueState("None");
					oCells[8].setValueState("None");
					oCells[9].setValueState("None");
					oCells[10].setValueState("None");
					oCells[11].setValue("");
				}
			}
			jQuery.sap.delayedCall(100, this, function() {
				this.getOwnerComponent()._onProcessFlowPress(this.getOwnerComponent().prevView);
			});
			sap.ui.core.BusyIndicator.show(10);
		},

		onSave: function() {
			debugger
			if (this.canProceed != null && this.canProceed.locked === true) {
				sap.m.MessageToast.show(this.canProceed.message);
				//this.lockUnansweredRows(sRowId)
			} else {
				var customer = this.getOwnerComponent()._getCustomer();
				var oOutlet = this.getOwnerComponent()._getOutlet();
				var accountId = customer.getAccountId();
				var callId = customer.getActivityId();
				var clgwwgFlag = "N";
				var oConfigModel = this.getView().getModel("priceReviewConfig");
				//var outlet = this.getOwnerComponent().getModel(callId);
	
				var priceAccountId = this.byId("priceaccountid").getText();
	
				var priceAssessId = this.byId("priceassessid").getText();
	
				// Create update payload
				var items = [];
	
				if (oOutlet.getAddress().toLowerCase().indexOf("clg/wwg") !== -1) {
					clgwwgFlag = "Y";
				}
	
				// Create update payload
	
				//			data.accountId = accountId;
				//			data.assessId = assessId;
				//			data.retailReviews = items;
				//			data.priceReviews = [];
	
				// Get update values from table
				var table = this.byId("tblPriceReview");
	
				var cells = table.getItems();
				var mandatoryDiscrepencyFieldsSpecified = false;
				var priceNotSpecified = false;
				var prevView = this.getOwnerComponent().prevView;
				for (var i = 0; i < cells.length; i++) {
					var cell = cells[i].getCells();
					var priceDiscrepency = cell[7].getSelectedKey();
					if (priceDiscrepency !== 'No - Above' && priceDiscrepency !== 'No - Below') {
						cell[8].setEditable(false);
						if (priceDiscrepency == "") {
							cell[7].setValueState("Error");
						}
					} else {
						var actualPrice = cell[8].getValue().slice(1).trim();
						if(isNaN(Number(actualPrice)) || Number(actualPrice) === 0) {
							actualPrice = "";
						}
						if (actualPrice == "") {
							priceNotSpecified = true;
							cell[8].setValueState("Error");
							sap.m.MessageToast.show("Actual Price needs to be specified for No-Above and No-Below");
						}
					}
					if (this.getOwnerComponent().prevView === "plan") {
	
						items.push({
							"id": cell[0].getText(),
							"priceCorrectInStore": cell[7].getSelectedKey(),
							"actualPrice": cell[8].getValue().slice(1).trim(),
							"priceAmended": cell[9].getSelectedKey(),
							"reasonCode": cell[10].getSelectedKey(),
							"comments": cell[11].getValue()
						});
					} else {
						var priceAmended = cell[9].getSelectedKey();
							var reasonCode = cell[10].getSelectedKey();
						if (priceDiscrepency.indexOf("Above") !== -1) {
							
							if (priceAmended === "" || reasonCode === "") {
								cell[9].setValueState("Error");
								cell[10].setValueState("Error");
							} else {
								cell[9].setValueState("None");
								cell[10].setValueState("None");
							}
						} else if(priceDiscrepency.indexOf("Ranged") !== -1) {
							if(reasonCode === "") {
								cell[10].setValueState("Error");
							} else {
								cell[10].setValueState("None");
							}
						}
						items.push({
							"id": cell[0].getText(),
							"priceCorrectInStore": cell[7].getSelectedKey(),
							"actualPrice": cell[8].getValue().slice(1).trim(),
							"priceAmended": cell[9].getSelectedKey(),
							"reasonCode": cell[10].getSelectedKey(),
							"comments": cell[11].getValue()
						});
					}
				}
				
				mandatoryDiscrepencyFieldsSpecified = !(
					items.filter(function(item){
						return item.priceCorrectInStore.indexOf("Above") > 0 && (
							( item.priceAmended == "" || item.priceAmended == null ) ||
							( item.reasonCode == "" || item.reasonCode == null )
						);
					}).length
				);
				
				var notRangedDiscrepencyFieldSpecified = !items.filter(function(item){
					return item.priceCorrectInStore.indexOf("Ranged") > 0 &&
					(item.reasonCode === "" || item.reasonCode == null);
				}).length;	
				
	
				var emptyPriceChecks = items.filter(function(item) {
					return !item.priceCorrectInStore;
				});
	
				if (emptyPriceChecks.length > 0) {
					sap.m.MessageToast.show("Price Checks cannot be empty");
				} else if (priceNotSpecified) {
					sap.m.MessageToast.show("Actual Price needs to be specified when price discrepency is No - Above and No - Below");
				} else if (!mandatoryDiscrepencyFieldsSpecified && prevView === "sell") {
					sap.m.MessageToast.show("Price Amended and Reason Code cannot be empty for Discrepency");
				} else if(!notRangedDiscrepencyFieldSpecified && prevView === "sell") {
					sap.m.MessageToast.show("Reason Code cannot be empty for Discrepency");
				} else {
					jQuery.sap.delayedCall(100, this, function() {
						// Save values.
						debugger
						sap.m.MessageToast.show("Updating Price Review");
						this.getOwnerComponent()._setPriceReviewData(this,
							priceAccountId,
							callId,
							priceAssessId,
							items,
							oOutlet.getActivityId(),
							clgwwgFlag);
	
					});
					sap.ui.core.BusyIndicator.show(10);
	
					var oDiscrepencies = items.filter(function(item) {
						return item.priceCorrectInStore.indexOf("-") !== -1;
					});
	
					var bCreateDiscrepency = oDiscrepencies.length > 0;
					if (bCreateDiscrepency && prevView === "plan") {
						sap.m.MessageToast.show("A Discrepency will be created", {
							onClose: function() {
							//	sap.ui.core.BusyIndicator.show(10);
							}
						});
					} else {
					//	sap.ui.core.BusyIndicator.show(10);
					}
	
				}		
			}
		},
		priceFormat: function(value) {
			return "$" + value;
		},
		
		priceCorrectFormatter: function(prevView) {
			prevView = this.getOwnerComponent().prevView;
			if(prevView === "sell") {
				return false;
			}
			return true;
		},

		priceCorrectInStoreChange: function(event) {
			debugger
			var oParams = event.getParameters();
			var oItem = oParams.selectedItem;
			var oControl = event.getSource();
			var prevView = this.getOwnerComponent().prevView;
			
			var sId = oControl.getId();
			var $row = $('#' + sId).closest("tr");
			var sRowId;
			if($row.length > 0) {
				sRowId = $row.prop("id");
			}    
			
			var oInput = event.getSource().getParent().getCells()[8];
			var oPriceAmended = event.getSource().getParent().getCells()[9];
			var oReasonCode = event.getSource().getParent().getCells()[10];
			var prevEditable = oInput.getEditable();
			var oRRP = event.getSource().getParent().getCells()[6];
			var sText = oItem.getText();
			var sRRP = Number(oRRP.getText().slice(1));
			var sValue = oInput.getValue().slice(1);
			var sValueNum;
			if(sValue === "") {
				sValueNum = null;
			} else {
				sValueNum = Number(oInput.getValue().slice(1));
			}
			
			
			var sPriceAmended = oPriceAmended.getValue();
			var sReasonCode = oReasonCode.getValue();

			switch (sText) {
				case 'No - Above': {
					oInput.setEditable(true);
					oInput.setRequired(true);
					if (sValue === "" || sValue ==  null) {
						oInput.setValueState("Error");
						oInput.attachChange(this.onLockingControlChange, this);
						this.canProceed = {
							row: sRowId,
							fields: [
								oInput.getId()
							],
							message: "Actual Price cannot be empty"
						};
						this.lockUnansweredRows(sRowId);
					} else if (sRRP >= sValueNum) {
						oInput.setValueState(sap.ui.core.ValueState.Error);
						oInput.setValueState("Error");
						oInput.attachChange(this.onLockingControlChange, this);
						this.canProceed = {
							row: sRowId,
							fields: [
								oInput.getId()
							],
							message: "Actual Price must be higher than RRP"
						};
						this.lockUnansweredRows(sRowId);
					}  else {
						oInput.setValueState(sap.ui.core.ValueState.None);
						oInput.detachChange(this.onLockingControlChange, this);
						if(prevView === "plan") {
							this.unlockAllRows();	
						}
					}	
					
					if (prevView === "sell") {
						
						var addToExisting = false;
						
						if(sValue === "" || sValue == null) {
							addToExisting = true;
						}
						
						if( (sPriceAmended === "" || sPriceAmended == null) || (sReasonCode === "" || sReasonCode == null)) {
							this.lockUnansweredRows(sRowId);
							if((sPriceAmended === "" || sPriceAmended == null) && (sReasonCode === "" || sReasonCode == null)) {
								oPriceAmended.setValueState("Error");
								oReasonCode.setValueState("Error");
								oPriceAmended.attachSelectionChange(this.onLockingControlChange, this);
								oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
								if(addToExisting) {
									this.canProceed.fields.push(oPriceAmended.getId());
									this.canProceed.fields.push(oReasonCode.getId());
									this.canProceed.message = "Actual Price, Price Amended and Reason Code cannot be empty when Price Correct in Store is No Above and a discrepency has been created";
								} else {
									this.canProceed = {
										row: sRowId,
										message: "Price Amended and Reason Code cannot be empty when Price Correct in Store is No Above and a discrepency has been created",
										fields: [oPriceAmended.getId(), oReasonCode.getId()]
									};
								}
							} else if(sPriceAmended === "" || sPriceAmended == null) {
								oPriceAmended.setValueState("Error");
								oPriceAmended.attachSelectionChange(this.onLockingControlChange, this);
								oReasonCode.setValueState("None");
								oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
								if(addToExisting) {
									this.canProceed.fields.push(oReasonCode.getId());
									this.canProceed.message = "Actual Price and Price Amended cannot be empty when Price Correct in Store is No Above and a discrepency has been created";
									
								} else {
									this.canProceed = {
										row: sRowId,
										message: "Price Amended cannot be empty when Price Correct in Store is No Above and a discrepency has been created",
										fields: [oPriceAmended.getId()]
									};
								}
							} else if(sReasonCode === "" || sReasonCode == null) {
								oReasonCode.setValueState("Error");
								oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
								oPriceAmended.setValueState("None");
								oPriceAmended.detachSelectionChange(this.onLockingControlChange, this);
								if(addToExisting) {
									this.canProceed.fields.push(oPriceAmended.getId());
									this.canProceed.message = "Actual Price and ReasonCode cannot be empty when Price Correct in Store is No Above and a discrepency has been created";
								} else {
									this.canProceed = {
										row: sRowId,
										message: "Reason Code cannot be empty when Price Correct in Store is No Above and a discrepency has been created",
										fields: [oPriceAmended.getId()]
									};
								}
							} else {
								oReasonCode.setValueState("None");
								oPriceAmended.setValueState("None");
								oPriceAmended.detachSelectionChange(this.onLockingControlChange, this);
								oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
								if(!addToExisting) {
									this.unlockAllRows();
								}
							}
						}				
					}
					
					if(this.canProceed != null && this.canProceed.message != null) {
						sap.m.MessageToast.show(this.canProceed.message);
					}
						
					break;
				}
 
				case 'No - Below':
					{
						oInput.setEditable(true);
						oReasonCode.setEditable(false);
						oPriceAmended.setEditable(false);
						oPriceAmended.setValueState("None");
						oReasonCode.setValueState("None");
						// oReasonCode.setRequired(false);
						//oPriceAmended.setRequired(true);
						//oReasonCode.setRequired(true);
						//oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
						//oPriceAmended.detachSelectionChange(this.onLockingControlChange, this);
						oInput.setRequired(true);
						oInput.setValueState(sap.ui.core.ValueState.Error);
						debugger
						if(isNaN(Number(sValue)) || Number(sValue) === 0) {
							sValue = "";
						}
						
						
						if (sValue === "" || sValue ==  null) {
								oInput.setValueState("Error");
								oInput.attachChange(this.onLockingControlChange, this);
								this.canProceed = {
									row: sRowId,
									fields: [
									oInput.getId()
								],
								message: "Actual Price cannot be empty"
							};
							this.lockUnansweredRows(sRowId);
						} else if (sRRP <= sValueNum) {
							oInput.setValueState(sap.ui.core.ValueState.Error);
							
							oInput.attachChange(this.onLockingControlChange, this);
								this.canProceed = {
									row: sRowId,
									fields: [
									oInput.getId()
								],
								message: "Actual Price cannot be higher than RRP"
							};
							this.lockUnansweredRows(sRowId);
						} 
						
					// 	if (prevView === "sell") {
						
					// 	var addToExisting = false;
						
					// 	if(sValue === "" || sValue == null) {
					// 		addToExisting = true;
					// 	}
						
					// 	if( (sPriceAmended === "" || sPriceAmended == null) || (sReasonCode === "" || sReasonCode == null)) {
					// 		this.lockUnansweredRows(sRowId);
					// 		if((sPriceAmended === "" || sPriceAmended == null) && (sReasonCode === "" || sReasonCode == null)) {
					// 			oPriceAmended.setValueState("Error");
					// 			oReasonCode.setValueState("Error");
					// 			oPriceAmended.attachSelectionChange(this.onLockingControlChange, this);
					// 			oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
					// 			if(addToExisting) {
					// 				this.canProceed.fields.push(oPriceAmended.getId());
					// 				this.canProceed.fields.push(oReasonCode.getId());
					// 				this.canProceed.message = "Actual Price, Price Amended and Reason Code cannot be empty when Price Correct in Store is No Below and a discrepency has been created";
					// 			} else {
					// 				this.canProceed = {
					// 					row: sRowId,
					// 					message: "Price Amended and Reason Code cannot be empty when Price Correct in Store is No Below and a discrepency has been created",
					// 					fields: [oPriceAmended.getId(), oReasonCode.getId()]
					// 				};
					// 			}
					// 		} else if(sPriceAmended === "" || sPriceAmended == null) {
					// 			oPriceAmended.setValueState("Error");
					// 			oPriceAmended.attachSelectionChange(this.onLockingControlChange, this);
					// 			oReasonCode.setValueState("None");
					// 			oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
					// 			if(addToExisting) {
					// 				this.canProceed.fields.push(oReasonCode.getId());
					// 				this.canProceed.message = "Actual Price and Price Amended cannot be empty when Price Correct in Store is No Below and a discrepency has been created";
									
					// 			} else {
					// 				this.canProceed = {
					// 					row: sRowId,
					// 					message: "Price Amended cannot be empty when Price Correct in Store is No Below and a discrepency has been created",
					// 					fields: [oPriceAmended.getId()]
					// 				};
					// 			}
					// 		} else if(sReasonCode === "" || sReasonCode == null) {
					// 			oReasonCode.setValueState("Error");
					// 			oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
					// 			oPriceAmended.setValueState("None");
					// 			oPriceAmended.detachSelectionChange(this.onLockingControlChange, this);
					// 			if(addToExisting) {
					// 				this.canProceed.fields.push(oPriceAmended.getId());
					// 				this.canProceed.message = "Actual Price and ReasonCode cannot be empty when Price Correct in Store is No Below and a discrepency has been created";
					// 			} else {
					// 				this.canProceed = {
					// 					row: sRowId,
					// 					message: "Reason Code cannot be empty when Price Correct in Store is No Below and a discrepency has been created",
					// 					fields: [oPriceAmended.getId()]
					// 				};
					// 			}
					// 		} else {
					// 			oReasonCode.setValueState("None");
					// 			oPriceAmended.setValueState("None");
					// 			oPriceAmended.detachSelectionChange(this.onLockingControlChange, this);
					// 			oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
					// 			if(!addToExisting) {
					// 				this.unlockAllRows();
					// 			}
					// 		}
					// 	}				
					// } 
					else {
							oInput.setValueState(sap.ui.core.ValueState.None);
							if(this.canProceed != null) {
								this.canProceed.locked = false;
								this.canProceed.fields = [];
								this.canProceed.message = null;
							}
							this.unlockAllRows();		
						}
						break;
					}
				case 'Not Ranged': {
					oInput.setValue("");
					oInput.setValueState("None");
					oInput.setEditable(false);
					oInput.setRequired(false);
					oInput.detachChange(this.onLockingControlChange);
					if(prevView === "sell") {
						console.log('Reason code is mandatory when the value is Not-Ranged');
					if(sReasonCode === "" || sReasonCode == null) {
						//oInput.detachChange(this.onLockingControlChange, this);
						oReasonCode.setValueState("Error");
						oPriceAmended.setValueState("None");
						oInput.setValueState("None");
						oInput.setRequired(false);
						oReasonCode.setRequired(false);
						oReasonCode.setRequired(true);
						oReasonCode.setEditable(true);
						oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
						this.canProceed = {
								row: sRowId,
								fields: [
								oReasonCode.getId()
							],
							message: "Reason Code cannot be empty"
						};
						this.lockUnansweredRows(sRowId);
					} else {
							oReasonCode.setValueState("None");
							oReasonCode.setEditable(true);
							oReasonCode.setRequired(false);
							oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
							if(this.canProceed != null) {
								this.canProceed.locked = false;
								this.canProceed.fields = [];
								this.canProceed.message = null;
							}
							this.unlockAllRows();
						}	
					} else {
							oReasonCode.setValueState("None");
							oReasonCode.setRequired(false);
							oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
							if(this.canProceed != null) {
								this.canProceed.locked = false;
								this.canProceed.fields = [];
								this.canProceed.message = null;
							}
							this.unlockAllRows();
						}
					break;
				}
				default:
					{
						oInput.setRequired(false);
						oReasonCode.setRequired(false);
						oReasonCode.setValue("");
						oPriceAmended.setRequired(false);
						oPriceAmended.setValue("");
						oInput.setValue("");
						oReasonCode.setValueState("None");
						oPriceAmended.setValueState("None");
						oInput.setValueState("None");
						oInput.setEditable(false);
						oReasonCode.setEditable(false);
						oPriceAmended.setEditable(false);
						if(this.canProceed != null) {
							this.canProceed.locked = false;
							this.canProceed.fields = [];
							this.canProceed.message = null;
						}
						this.unlockAllRows();
						
					}
			}
			if (sText !== "") {
				oControl.setValueState("None");
			}
			
			if(this.canProceed != null && this.canProceed.message != null) {
				sap.m.MessageToast.show(this.canProceed.message);
			}
			
		},
		
		

		onActualPriceAdded: function(event) {
			var oParams = event.getParameters();
			var oInput = event.getSource();
			var sValue = oParams.value.slice(1).trim();
			var sBindingPath = event.getSource().getBindingContext("PriceReview").getPath();
			var oModel = this.getOwnerComponent().getModel("PriceReview");
			var prevView = this.getOwnerComponent().prevView;
			
			
			var sId = oInput.getId();
			var $row = $('#' + sId).closest("tr");
			var sRowId;
			if($row.length > 0) {
				sRowId = $row.prop("id");
			}

			var sPriceDiscrepencyType = oModel.getProperty(sBindingPath + "/review:valueFieldA");
			var sValueNum;
			var sRRP;
			
			if(sPriceDiscrepencyType.indexOf("-") > 0 && prevView === "plan") {
				// test for crazy values here:
				debugger
				var bInvalid  = this.validateBadInput(oParams.value,sRowId,oInput);
				if(bInvalid) {
					return;
				}
			}			

			
			// ensure that we have a Number here
			if (sValue != null && sValue !== "" && !isNaN(Number(sValue))) {
				sValueNum = Number(sValue);
				sRRP = Number(oModel.getProperty(sBindingPath + "/review:numberFieldA"));
				if (!isNaN(sRRP)) {
					switch (sPriceDiscrepencyType) {
						case 'No - Above':
							{
								if (sRRP >= sValueNum) {
									
									oInput.setValueState(sap.ui.core.ValueState.Error);
									sap.m.MessageToast.show("Actual Price must be higher than RRP");
									this.canProceed = {
										row: sRowId,
										fields: [oInput.getId()],
										message: 'Actual Price must be higher than RRP'
									};
									oInput.attachChange(this.onLockingControlChange, this);
									this.lockUnansweredRows(sRowId);
								} else {
									this.unlockAllRows();             
									oInput.detachChange(this.onLockingControlChange, this);
									oInput.setValueState(sap.ui.core.ValueState.None);
								}
								break;
							}
						case 'No - Below':
							{
								if (sRRP <= sValueNum) {
									oInput.setValueState(sap.ui.core.ValueState.Error);
									sap.m.MessageToast.show("Actual Price must be higher than RRP");
									this.canProceed = {
										row: sRowId,
										fields: [oInput.getId()],
										message: 'Actual Price must be lower than RRP'
									};
									oInput.attachChange(this.onLockingControlChange, this);
									this.lockUnansweredRows(sRowId);
									sap.m.MessageToast.show("Actual Price must be lower than RRP");
								} else {
									this.unlockAllRows();             
									oInput.detachChange(this.onLockingControlChange, this);
									oInput.setValueState(sap.ui.core.ValueState.None);
								}
								break;
							}
						default:
							{
								oInput.setEditable(false);
								oInput.setValue("");
								oInput.setValueState(sap.ui.core.ValueState.None);
							}
					}
				}
			}
			if (sPriceDiscrepencyType.indexOf("-") !== -1) {
				if (sValue === "") {
					oInput.setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageToast.show("Actual Price is invalid");
					this.canProceed = {
						message: 'Actual Price cannot be empty or anything but a number',
						row: sRowId,
						fields: [oInput.getId()]
					};
					this.lockUnansweredRows(sRowId);
					oInput.attachChange(this.onLockingControlChange, this);
				} else if (sValue !== "" && sValue.length > 0 && isNaN(Number(sValue.slice(1)))) {
					
					oInput.setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageToast.show("Actual Price must be a number");
					this.canProceed = {
						message: 'Actual Price cannot be empty or anything but a number',
						row: sRowId,
						fields: [oInput.getId()]
					};
					this.lockUnansweredRows(sRowId);
					oInput.attachChange(this.onLockingControlChange, this);
				}
			} else {
				oInput.setValueState(sap.ui.core.ValueState.None);
				this.unlockAllRows();
				oInput.detachChange(this.onLockingControlChange, this);
				oInput.setRequired(false);
			}
		},

		onReasonCodeChange: function(oEvent) {
			var oControl = oEvent.getSource();
			var sValue = oEvent.getParameters().value;
			var prevView = this.getOwnerComponent().prevView;
			if (sValue != "" && prevView === "sell") {
				oControl.setValueState("None");
			}
		},
		
		validateBadInput: function(sValue, sRowId, oInput) {
			var regexp = /([A-Za-z_!@#$%^&*()-+=?/.,;:'"~`]*)?\s*(\d+\.?\d{0,2})/;
			var matches = regexp.exec(sValue);
			if(matches != null && Array.isArray(matches) && matches.length >= 3) {
				var symbol = matches[1];
				var value = matches[2];
				if(value != null && typeof value === "string") {
					value = value.trim();
				}
				if(symbol !== "$") {
					var currencyModel = this.getView().getModel("priceReviewCurrency");
					if(currencyModel != null) {
						currencyModel.setProperty("currency", "$");
						/*
							NOT NULL
							NOT EMPTY
							IS A NUMBER
							NOT ZERO
						*/
						if(value !== "" && value != null && !isNaN(Number(value)) && Number(value) !== 0) {
							oInput.setValue("$ " + value);
							oInput.detachChange(this.onLockingControlChange, this);
							oInput.setValueState("None");
							this.unlockAllRows();
							return false;
						} else {
							this.canProceed = {
								row: sRowId,
								message: 'Currency code must be $ and value cannot be empty, it must be a number',
								fields: [oInput.getId()]
							};
							oInput.attachChange(this.onLockingControlChange, this);
							oInput.setValueState("Error");
							sap.m.MessageToast.show('Currency code must be $ and value cannot be empty, it must be a number');
							this.lockUnansweredRows(sRowId);
							return true;
						}
						return true;
					}
					return true;
				} else if (value === "" || value == null || isNaN(Number(value)) || Number(value) === 0) {
						this.canProceed = {
								row: sRowId,
								message: 'Currency code must be $ and value cannot be empty, it must be a number',
								fields: [oInput.getId()]
							};
							
							oInput.attachChange(this.onLockingControlChange, this);
							oInput.setValueState("Error");
							sap.m.MessageToast.show('Currency code must be $ and value cannot be empty, it must be a number');
							this.lockUnansweredRows(sRowId);
							return true;
				} else {
					oInput.detachChange(this.onLockingControlChange, this);
					oInput.setValueState("None");
					this.unlockAllRows();
					return false;
				}
				return true;
			} else {
				this.canProceed = {
					row: sRowId,
					message: 'Currency code must be $ and value cannot be empty, it must be a number',
					fields: [oInput.getId()]
				};
				oInput.attachChange(this.onLockingControlChange, this);
				oInput.setValueState("Error");
				sap.m.MessageToast.show('Currency code must be $ and value cannot be empty, it must be a number');
				this.lockUnansweredRows(sRowId);
				return true;
			}
		}

	});

});