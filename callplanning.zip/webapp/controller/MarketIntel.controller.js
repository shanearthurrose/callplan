sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("callplanning.controller.MarketIntel", {

		onInit: function() {
			// TO DO
			var oRouter = this.getOwnerComponent().getRouter();
			/*
			Attach a listener to the view, so fm: _selectItemWithId will be called everytime this view is triggered via Route
			*/

			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "marketintel") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));
			}, this);
		},

		_selectItemWithId: function(arg) {
			var oCustomer = this.getOwnerComponent()._getCustomer();
			//implementation
			var callId = oCustomer.getActivityId();
			var oOutlet = this.getOwnerComponent()._getOutlet();

			this.getOwnerComponent()._getMarketIntel(this.byId("tblMarketIntel"), oOutlet.getActivityId());

			sap.ui.core.BusyIndicator.hide();
		},

		onBack: function() {
			//	window.history.go(-1);
			jQuery.sap.delayedCall(100, this, function() {
				this.getOwnerComponent()._onProcessFlowPress(this.getOwnerComponent().prevView);
			});
			sap.ui.core.BusyIndicator.show(10);
		},

		onSave: function() {
			// TODO
			var customer = this.getOwnerComponent()._getCustomer();
			var oOutlet = this.getOwnerComponent()._getOutlet();

			var callId = customer.getActivityId();

			//var accountId = "1-2N361U";
			//var callId = "1-4BETNAW"; 
			//var assessId = outlet.marketintelid;

			var activityId = this.byId("acctivityId").getText();
			var assessId = this.byId("assessId").getText();

			//	alert(assessId);

			// Create update payload
			var items = [];

			// Get update values from table
			var table = this.byId("tblMarketIntel");
			var cells = table.getItems();
			var complete = true;

			for (var i = 0; i < cells.length; i++) {
				var cell = cells[i].getCells();
				if (cell[5].getSelectedItem() !== null) {
					//	alert(cell[0].getText());
					items.push({
						"id": cell[0].getText(),
						"value": cell[5].getSelectedItem().getText(),
						"score": cell[5].getSelectedItem().getKey(),
						"comments": cell[6].getValue(),
						"attributeName": cell[2].getText(),
						"attribId": cell[1].getText()
					});
				} else {
					items.push({
						"id": cell[0].getText(),
						"value": "",
						"score": "",
						"comments": cell[6].getValue(),
						"attributeName": cell[2].getText(),
						"attribId": cell[1].getText()
					});
					complete = false;

				}
			}

			jQuery.sap.delayedCall(100, this, function() {
				// Save values.
				sap.m.MessageToast.show("Updating Market Intel");
				this.getOwnerComponent()._updateMarketIntel(activityId, assessId, items, oOutlet.getActivityId(), complete);

			});

			sap.ui.core.BusyIndicator.show(10);

		}
	});

});