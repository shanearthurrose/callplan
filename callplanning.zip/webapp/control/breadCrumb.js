/*jQuery.sap.registerModulePath("SignaturePad", "./control/SignaturePad");*/
sap.ui.define(["sap/ui/core/Control"], function(oControl) {
	"use strict";
	return oControl.extend("callplanning.control.breadCrumb", {

		metadata: {
			properties: {
				"width": {
					type: "sap.ui.core.CSSSize",
					defaultValue: "23%"
				},
				"height": {
					type: "sap.ui.core.CSSSize",
					defaultValue: "24px"
				},
				"thickness": {
					type: "int",
					defaultValue: 2
				},
				"class": {
					type: "string",
					defaultValue: "crumb"
				},
				/* Business Object properties */
				text: {
					type: "string"
				},
				rightArrow: {
					type: "boolean"
				},

				leftArrow: {
					type: "boolean"
				},
				selected: {
					type: "boolean"
				}
			},
			events: {
				"select": {}
			}
		},

		renderer: function(oRm, oControl) {
			var thickness = parseInt(oControl.getProperty('thickness'), 10);

			var rightClass = "rightbackground";
			var leftClass = "leftbackground";
			var labelClass = "label";
			
			if (oControl.getSelected() === true) { 
			   rightClass = rightClass + "selected";
			   leftClass = leftClass + "selected";
			   labelClass = labelClass + "selected";
			}

			oRm.write("<div");
			oRm.writeControlData(oControl);

			oRm.addClass("crumb");
			oRm.writeClasses();

			oRm.addStyle("width", oControl.getWidth());
			oRm.addStyle("height", oControl.getHeight());
			oRm.writeStyles();

			oRm.write(">");

			//	alert(oControl.getRightArrow());
			//oRm.write("<div id='boxmain'>");
			if (oControl.getLeftArrow() === true) {
				oRm.write("<div class='" + leftClass + "'>");
				oRm.write("<div class='left'>");
				oRm.write("</div>");
				oRm.write("</div>");
			} else {
				oRm.write("<div class='" + leftClass + "'>");
				oRm.write("<div class='noleft'>");
				oRm.write("</div>");
				oRm.write("</div>");
			}

			oRm.write("<div class='"+labelClass+"'>");
			oRm.write(oControl.getText());
			oRm.write("</div>");

			if (oControl.getRightArrow() === true) {
				oRm.write("<div class='" + rightClass + "'>");
				oRm.write("<div class='right'>");
				oRm.write("</div>");
				oRm.write("</div>");
			} else {
				oRm.write("<div class='" + rightClass + "'>");
				oRm.write("<div class='noright'>");
				oRm.write("</div>");
				oRm.write("</div>");
			}

			oRm.write("</div>");

		},

		onAfterRendering: function() {

		},

		onclick: function(ev) {
			//Triggered when control is clicked
			this.fireSelect();
		},

		clear: function() {

		},
		save: function() {

		}
	});
});