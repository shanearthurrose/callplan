/*jQuery.sap.registerModulePath("SignaturePad", "./control/SignaturePad");*/
sap.ui.define(["sap/ui/core/Control"], function(oControl) {
	"use strict";
	return oControl.extend("callplanning.control.box", {

		metadata: {
			properties: {
				"width": {
					type: "sap.ui.core.CSSSize",
					defaultValue: "145px"
				},
				"height": {
					type: "sap.ui.core.CSSSize",
					defaultValue: "100px"
				},
				"thickness": {
					type: "int",
					defaultValue: 2
				},
				"bgcolor": {
					type: "sap.ui.core.CSSColor",
					defaultValue: "white"
				},
				"signcolor": {
					type: "sap.ui.core.CSSColor",
					defaultValue: "black"
				},
				"class": {
					type: "string",
					defaultValue: "box"
				},
				/* Business Object properties */
				accountName: {
					type: "string"
				},

				accountId: {
					type: "string"
				},
				type: {
					type: "string"
				},
				subType: {
					type: "string"
				},
				activityId: {
					type: "string"
				},
				callDate: {
					type: "string"
				},
				accountNumber: {
					type: "string"
				},
				address: {
					type: "string"
				},
				callDuration: {
					type: "string"
				},
				callStatus: {
					type: "string"
				},
				callRescheduleFlag: {
					type: "string"
				},
				callRescheduleValue: {
					type: "string",
					defaultValue: "R"
				},
				callFrequency: {
					type: "string"
				},
				reschedule: {
					type: "string"
				},
				unscheduled: {
					type: "string"
				},
				startDate: {
					type: "string"
				},
				endDate: {
					type: "string"
				},
				nextCallDate: {
					type: "string"
				},
				contactUID: {
					type: "string"
				},
				image: {
					type: "string"
				},
				selected: {
					type: "boolean",
					defaultValue: false
				}
			},
			events: {
				"select": {}
			}
		},

		onInit: function() {
			this.status = "";
		},

		renderer: function(oRm, oControl) {
			var thickness = parseInt(oControl.getProperty('thickness'), 10);
			var status = "normal";
			var frequency = "";

			//callRescheduleFlag
			if (oControl.getCallStatus()) {
				if (oControl.getCallStatus() === "Achieved" || oControl.getCallStatus() === "Sold In") {
					status = "closed";
					oControl.setSelected(true);
				} else if (oControl.getCallStatus() === "In Progress" || oControl.getCallStatus().toLowerCase().indexOf("reschedule") !== -1) {
					status = "inprogress";
					oControl.setSelected(true);
				} else if (oControl.getCallStatus() === "Submitted" && (oControl.getCallRescheduleFlag() === "Y")) {
					status = "inprogress";
					oControl.setSelected(true);
				} else if (oControl.getCallStatus() === "Not Achieved" || oControl.getCallStatus() === "Unachieved") {
					status = "notachieved";
					oControl.setSelected(true);
				} else {
					status = "open";
				}
			}

			//this.setStatus(status);
			//	alert(oControl.getNextCallDate());

			//sap.m.MessageToast.show("here:"+oControl.getCallFrequency());
			if (oControl.getCallFrequency()) {
				if (oControl.getCallFrequency() === "Every 4 weeks") {
					frequency = "M";
				} else if (oControl.getCallFrequency() === "Fortnightly") {
					frequency = "F";
				} else {
					frequency = "W";
				}
			}

			//alert(oControl.getCallDate() + this.nextCall());

			oRm.write("<div");
			oRm.writeControlData(oControl);
			if (oControl.getCallDate()) {
				oRm.write("data-calldate='" + oControl.getCallDate() + "' ");
			}
			//oRm.write("data-accountid=[" + oControl.getAccountNumber() + "]");
			oRm.write("data-accountid='" + oControl.getAccountId() + "'");

			oRm.addClass("visitTile " + status + 'Border');
			oRm.writeClasses();
			oRm.write("data-activityid=" + oControl.getActivityId() + "");



			oRm.addStyle("width", oControl.getWidth());
			oRm.addStyle("height", oControl.getHeight());
			oRm.writeStyles();

			oRm.write(">");

			//oRm.write("<div id='boxmain'>");
			oRm.write("<div class='duration " + status + "Background'>");
			oRm.write("<div class='subleft1'>");
			if (oControl.getCallDuration() !== "") {
				oRm.write(oControl.getCallDuration());
			}
			oRm.write("</div>");

			oRm.write("<div class='subleft2'>");
			oRm.write(frequency);
			oRm.write("</div>");
			oRm.write("</div>");

			oRm.write("<div class='visitDetails'>");
			oRm.write("<div class='accountname'>");
			oRm.write(oControl.getAccountName());
			oRm.write("</div>");

			oRm.write("<div class='accountId' id=" + oControl.getAccountId() + ">");
			if (oControl.getAccountNumber()) {
				oRm.write("Account: " + oControl.getAccountNumber());
			}
			oRm.write("</div>");

			oRm.write("<div class='submid3'>");
			oRm.write(oControl.getAddress());
			oRm.write("</div>");
			oRm.write("</div>");

			/*   add reschedule class    */

			oRm.write("<div id='reschedule'");
			if (oControl.getReschedule() === "Y") {
				oRm.write("class='reschedule'");
			}

			oRm.write(">");

			oRm.write("<div id='reschedulevalue' class='subright1'>");
			if (oControl.getCallRescheduleValue()) {
				oRm.write(oControl.getCallRescheduleValue());
			}
			oRm.write("</div>");

			oRm.write("<div class='subright2'>");
			oRm.write("");
			oRm.write("</div>");

			oRm.write("<div id='unscheduledvalue'");
			//alert(oControl.getUnscheduled());
			if (oControl.getUnscheduled() === "Unscheduled") {
				oRm.write("class='unscheduled'");
			}
			oRm.write(">");
			oRm.write("U");
			oRm.write("</div>");
			oRm.write("</div>");

			// bottom
			oRm.write("<div class='bottom'>");
			oRm.write("<div class='startdate'>");
			oRm.write(oControl.getStartDate());
			oRm.write("</div>");

			oRm.write("<div class='enddate'>");
			oRm.write(oControl.getEndDate());
			oRm.write("</div>");

			if (oControl.getImage()) {
				oRm.write("<image class='image' src='" + oControl.getImage() + "'/>");
			}
			oRm.write("</div>");

			oRm.write("</div>");

		},

		onAfterRendering: function() {

		},

		onclick: function(ev) {
			//Triggered when control is clicked
			this.fireSelect();
		},

		callFrequency: function() {

			if (this.getCallFrequency() === "Every 4 weeks") {
				return "M";
			} else if (this.getCallFrequency() === "Fortnightly") {
				return "F";
			} else {
				return "W";
			}

		},

		getNextCall: function() {
			//			alert(this.getNextCallDate());
			//			var yyyy = this.getCallDate()[6] + this.getCallDate()[7] + this.getCallDate()[8] + this.getCallDate()[9];
			//			var mm = this.getCallDate()[0] + this.getCallDate()[1];
			//			var dd = this.getCallDate()[3] + this.getCallDate()[4];
			//mm = parseInt(mm) + 1;

			//alert(yyyy+","+mm+","+dd);

			var date = new Date(this.getNextCallDate());

			//			var date = new Date(parseInt(yyyy), parseInt(mm - 1), parseInt(dd));

			//alert(this.getNextCallDate());
			//			if (this.callFrequency() === "W") {
			//				date.setDate(date.getDate() + 7);
			//			} else if (this.callFrequency() === "F") {
			//				date.setDate(date.getDate() + 14);
			//			} else {
			//				date.setDate(date.getDate() + 30);
			//			}
			//alert(date);
			return date;
		},

		clear: function() {

		},
		save: function() {

		}
	});
});