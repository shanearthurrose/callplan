/*jQuery.sap.registerModulePath("SignaturePad", "./control/SignaturePad");*/
sap.ui.define(["sap/ui/core/Control"], function(oControl) {
			"use strict";
			return oControl.extend("callplanning.control.list", {

					metadata: {
						properties: {
							"width": {
								type: "sap.ui.core.CSSSize",
								defaultValue: "140px"
							},
							"height": {
								type: "sap.ui.core.CSSSize",
								defaultValue: "100px"
							},
							"thickness": {
								type: "int",
								defaultValue: 2
							},
							"bgcolor": {
								type: "sap.ui.core.CSSColor",
								defaultValue: "white"
							},
							"signcolor": {
								type: "sap.ui.core.CSSColor",
								defaultValue: "black"
							},
							"class": {
								type: "string",
								defaultValue: "box"
							},
							/* Business Object properties */

							accountId: {
								type: "string"
							},

							activityId: {
								type: "string"
							},
							numberOfRadio: {
								type: "int"
							},
							description: {
								type: "string"
							},
							status: {
								type: "string"
							},
							selectedIndex: {
								type: "int"
							},
							startDate: {
								type: "string"
							},
							endDate: {
								type: "string"
							},
							image: {
								type: "string"
							}
						},
							events: {
								"select": {}
							}
						},

						renderer: function(oRm, oControl) {
							var thickness = parseInt(oControl.getProperty('thickness'), 10);

							//alert(oControl.getCallDate() + this.nextCall());

							oRm.write(
								"<div class='" + oControl.getClass() +
								" xx sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMHBox'>"
							);
							//			oRm.addClass(oControl.getClass());
							//			oRm.writeClasses();
							//			oRm.write(">");			

							// if image in first column

							if (oControl.getImage()) {
								oRm.write(
									"<div class='radioimage sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMFlexItem sapMHBox'>"
								);
								oRm.write("<div class='sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto'>");
								oRm.write("<img class='sapMImg' src='" + oControl.getImage() + "' style='width:30px;height:30px'>");
								oRm.write("</div>");
								oRm.write("</div>");
							}
							// text description
							oRm.write(
								"<div class='radiotext sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMFlexItem sapMHBox agendaitems'"
							);
							oRm.addClass(oControl.getClass());
							oRm.writeClasses();
							oRm.write(">");
							oRm.write(
								"<div class='sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMFlexItem sapMVBox'>"
							);
							oRm.write("<div class='sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto'>");
							oRm.write("<span class='h4 sapMText sapUiSelectable'>" + oControl.getDescription() + "</span>");
							oRm.write("</div>");
							oRm.write("</div>");
							oRm.write("</div>");

							// radio button group
							var radiogroup = "RG" + Math.floor((1 + Math.random()) * 0x10000).toString(16);
							var checkField = 0;
							if (oControl.getSelectedIndex()) {
								checkField = oControl.getSelectedIndex();
							}
							/*			
										if (oControl.getStatus()) {
											if (oControl.getStatus() === "Achieved" || oControl.getCallStatus() === "Sold In") {
												checkField = 1;
											} else if   (oControl.getCallStatus() === "In Progress" || (oControl.getCallStatus() === "Reschedule")) {
												checkField = 2;	
											} else if   (oControl.getCallStatus() === "Not Achieved") {
												checkField = 3;				
											}
										}
							*/

							//alert(oControl.getNumberOfRadio());
							for (var i = 1; i <= oControl.getNumberOfRadio(); i++) {
								//var unique = Math.floor((1 + Math.random()) * 0x10000).toString(16);
								var unique = radiogroup + "RB" + i;
								oRm.write(
									"<div class='radio sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMFlexItem sapMHBox agendaitems'"
								);
								oRm.addClass(oControl.getClass());
								oRm.writeClasses();
								oRm.write(">");
								oRm.write(
									"<div class='radio sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMFlexItem sapMVBox'>"
								);

								oRm.write("<div class='" + oControl.getActivityId() + " sapMRbG sapMRbG1Row sapUiMediumMarginBottom'>");

								if (i === checkField) {
									oRm.write("<input checked id='" + unique + "' data-radio='R" + i + "' type='radio' tabindex='-1' name='" + radiogroup + "'/>");
								} else {
									oRm.write("<input id='" + unique + "' data-radio='R" + i + "' type='radio' tabindex='-1' name='" + radiogroup + "'/>");
								}

								oRm.write("<label for='" + unique + "'></label>");
								oRm.write("<div class='check'><div class='inside'></div></div>");

								oRm.write("</div>");
								oRm.write("</div>");
								oRm.write("</div>");

							}

							// input comments
							oRm.write(
								"<div class='radioinput sapMFlexBox sapMFlexBoxAlignContentStretch sapMFlexBoxAlignItemsStretch sapMFlexBoxBGTransparent sapMFlexBoxJustifyStart sapMFlexBoxWrapNoWrap sapMFlexItem sapMHBox'>"
							);
							oRm.write("<div class='sapMFlexBoxBGTransparent sapMFlexItem sapMFlexItemAlignAuto'>");
							oRm.write("<div class='" + oControl.getActivityId() + " sapMInput sapMInputBase sapMInputBaseWidthPadding unachieved'>");
							oRm.write("<Input type='text' class='sapMInputBaseInner'/>");
							oRm.write("</div>");
							oRm.write("</div>");
							oRm.write("</div>");

							oRm.write("</div>");

						},

						onAfterRendering: function() {

						},

						onclick: function(ev) {
							//Triggered when control is clicked
							this.fireSelect();
						},

						clear: function() {

						},
						save: function() {

						}

					});
			});