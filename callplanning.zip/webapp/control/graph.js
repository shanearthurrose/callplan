/*jQuery.sap.registerModulePath("SignaturePad", "./control/SignaturePad");*/
sap.ui.define(["sap/ui/core/Control"], function(oControl) {
	"use strict";
	return oControl.extend("callplanning.control.graph", {

		metadata: {
			properties: {
				"width": {
					type: "sap.ui.core.CSSSize",
					defaultValue: "220px"
				},
				"height": {
					type: "sap.ui.core.CSSSize",
					defaultValue: "150px"
				},
				"thickness": {
					type: "int",
					defaultValue: 2
				},
				"bgcolor": {
					type: "sap.ui.core.CSSColor",
					defaultValue: "white"
				},
				"signcolor": {
					type: "sap.ui.core.CSSColor",
					defaultValue: "black"
				},
				"class": {
					type: "string",
					defaultValue: "gph-def"
				},
				/* Business Object properties */
				value: {
					type: "string"
				},
				min: {
					type: "string"
				},
				max: {
					type: "string"
				},
				title: {
					type: "string"
				},
				label: {
					type: "string"
				},
				target: {
					type: "string"
				},
				redlo: {
					type: "int"
				},
				redhigh: {
					type: "int"
				},
				amberlo: {
					type: "int"
				},
				amberhigh: {
					type: "int"
				},
				greenlo: {
					type: "int"
				},
				greenhigh: {
					type: "int"
				},
				ccclass: {
					type: "string"
				}
			},
			events: {
				"select": {}
			}
		},

		renderer: function(oRm, oControl) {
			var thickness = parseInt(oControl.getProperty('thickness'), 10);

			//	<div id="gauge" class="200x160px"></div>
			//alert(oControl.getCallDate() + this.nextCall());

			oRm.write("<div class=\""+oControl.getCcclass()+"\"");
			oRm.writeControlData(oControl);
			oRm.addStyle("width", oControl.getWidth());
			oRm.addStyle("height", oControl.getHeight());
			oRm.writeStyles();
			oRm.write(">");

			oRm.write("</div>");

		},

		onAfterRendering: function() {
			var id = '#' + this.getId();
			//var canvas = document.querySelector("canvas");

			//var canvas = this;
			try {
				this.graph = new JustGage({
					id: this.getId(),
					value: parseInt(this.getValue()),
					min: parseInt(this.getMin()),
					max: parseInt(this.getMax()),
					title: this.getTitle(),
					label: this.getLabel(),
					target: parseInt(this.getTarget()),
					pointer: "true",
					customSectors: {
						percents: true,
				    	ranges: [{
				          color : "#BB0000", //red
				          lo : this.getRedlo(),
				          hi : this.getRedhigh()
				        },{
				          color : "#E0AC00", //amber
				          lo : this.getAmberlo(),
				          hi : this.getAmberhigh()
				        },{
				          color : "#70B01C", //green
				          lo : this.getGreenlo(),
				          hi : this.getGreenhigh()
				        }]
				    }
				});
				
			} catch (e) {
				//    console.error(e);
			}
		},
		
		//Call compliance
		//0-69 red
		//70-75 amber
		//76-100 green

		onclick: function(ev) {
			//Triggered when control is clicked
			this.fireSelect();
		},

		callFrequency: function() {

			if (this.getCallFrequency() === "Every 4 weeks") {
				return "M";
			} else if (this.getCallFrequency() === "Fortnightly") {
				return "F";
			} else {
				return "W";
			}

		},

		getNextCall: function() {

			var yyyy = this.getCallDate()[6] + this.getCallDate()[7] + this.getCallDate()[8] + this.getCallDate()[9];
			var mm = this.getCallDate()[0] + this.getCallDate()[1];
			var dd = this.getCallDate()[3] + this.getCallDate()[4];
			//mm = parseInt(mm) + 1;

			//alert(yyyy+","+mm+","+dd);

			var date = new Date(parseInt(yyyy), parseInt(mm - 1), parseInt(dd));

			if (this.callFrequency() === "W") {
				date.setDate(date.getDate() + 7);
			} else if (this.callFrequency() === "F") {
				date.setDate(date.getDate() + 14);
			} else {
				date.setDate(date.getDate() + 30);
			}
			//alert(date);
			return date;
		},

		clear: function() {

		},
		save: function() {

		}
	});
});